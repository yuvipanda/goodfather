from distutils.core import setup
setup(name='goodfather',
	  version='0.0.1',
	  packages=['goodfather', 'goodfather.util']
	  )
		
